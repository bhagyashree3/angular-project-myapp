import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainhr',
  templateUrl: './mainhr.component.html',
  styleUrls: ['./mainhr.component.css']
})
export class MainhrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
